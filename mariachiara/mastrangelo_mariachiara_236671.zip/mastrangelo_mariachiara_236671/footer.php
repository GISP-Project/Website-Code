<footer class="row">
    <div class="col-12"><p>Sito di: Mariachiara Mastrangelo, ti trovi qui:<?php echo basename($_SERVER['PHP_SELF'])?></p> </div>
</footer>
