<?php
    $session = true;

if( session_status() === PHP_SESSION_DISABLED  )
    $session = false;
elseif( session_status() !== PHP_SESSION_ACTIVE )
{
	session_start();
}
?>
<!DOCTYPE html>
<html lang="it" >
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=yes">
    <meta name="author" content="Mariachiara Mastrangelo">
    <meta name="description" content="Accedi alla tua pagina personale per gestire i tuoi libri in prestito e prenderne di nuovi.">
    <meta name="keywords" content="bioblioteca, library, libro, book, prestito, online, restituzione">
    <link rel="icon" href="favicon.png" type="image/png" >
    <title>Login - Biblioteca online</title>
    <link rel="stylesheet" href="stile.css">

  </head>
  <body>
    <?php require 'header.php'; ?>
    <main class="row">

      <?php
      if (isset($_SESSION['user'])) {
        echo "Hai effettuato il login, per cambiare utente prima effettuare il logout.";
      } else {
        echo "<h2>Effettua l'accesso alla biblioteca</h2>";
        echo '<form method="post" onsubmit="return validaLogin(username.value, password.value)" action="login.php">
              <p><label>Username </label> <input type="text" name="username"';
              if (isset($_COOKIE["user_cookie"])) {
                echo 'value="' .$_COOKIE["user_cookie"]. '">';
              }else{
                echo 'placeholder="Username" >';
              }
        echo  '</p>
              <p><label>Password </label> <input type="password" name="password" id="passw" placeholder="Password"></p>
              <p><input type="submit"><input type="reset"></p>
              </form>';
      }
      if (!$session) {
        echo "le sessioni sono disabilitate";
      }else{
        if(isset($_REQUEST['username']) && isset($_REQUEST['password'])){
          $username = trim($_REQUEST['username']);
					$password = trim($_REQUEST['password']);
          $con = mysqli_connect("localhost", "uReadOnly", "posso_solo_leggere", "biblioteca");
          if (mysqli_connect_errno()) {
              echo "<p class='error'>Siamo spiacenti ma c'è stato un errore connessione al database: ".mysqli_connect_error()."</p>\n";
            }else{
                $query = "SELECT username FROM users WHERE username=? && pwd=? ";
                $stmt = mysqli_prepare($con, $query);
                mysqli_stmt_bind_param($stmt,"ss", $username, $password);
                $result= mysqli_stmt_execute($stmt);
                mysqli_stmt_bind_result($stmt,$user);
                if($user==''){
                  echo "<p class='error'>Lo username o la password inseriti risultano errati, riprova </p>";
                }
                if (!$result) {
                  echo "<p class='error'>Errore, query fallita: ".mysqli_error($con)."</p>\n";
                } else {
                if(mysqli_stmt_fetch($stmt)){
                  $_SESSION['user']=$username;
                }
                }
                mysqli_stmt_close($stmt);
              //libri attualmente in prestito all'utente loggato
                if (isset($_SESSION['user'])) {
                  setcookie("user_cookie", $username , time() + (86400 * 2), "/");
                  $query = "SELECT COUNT(*)
                            FROM books
                            WHERE prestito=?";
                  $stmt = mysqli_prepare($con, $query);
                  mysqli_stmt_bind_param($stmt,"s", $username);
                  $result = mysqli_stmt_execute($stmt);
                  mysqli_stmt_bind_result($stmt,$nlibri);
                  if (!$result) {
                    echo "<p class='error'>Errore, query fallita: ".mysqli_error($con)."</p>\n";
                  } else {
                    if(mysqli_stmt_fetch($stmt)){
                    $_SESSION['nlibri']=$nlibri;
                    header('location: libri.php');
                  }
                  }
                    mysqli_stmt_close($stmt);
                  }
                }
                mysqli_close($con);
            }

        }

       ?>
    </main>
    <?php require 'footer.php'; ?>
  </body>
</html>
