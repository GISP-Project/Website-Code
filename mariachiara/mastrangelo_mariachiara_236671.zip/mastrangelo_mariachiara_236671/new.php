<?php
    $session = true;

if( session_status() === PHP_SESSION_DISABLED  )
    $session = false;
elseif( session_status() !== PHP_SESSION_ACTIVE )
{
	session_start();
}
?>
<!DOCTYPE html>
<html lang="it" >
  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=yes">
    <meta name="author" content="Mariachiara Mastrangelo">
    <meta name="description" content="Registrati alla biblioteca online per prendere in prestito i nostri libri comodamente da casa tua.">
    <meta name="keywords" content="bioblioteca, library, libro, book, prestito, online, restituzione">
    <link rel="icon" href="favicon.png" type="image/png" >
    <title>Registrati - Biblioteca online</title>
    <link rel="stylesheet" href="stile.css">
    <script type="text/javascript" src="validatore.js" ></script>
  </head>
  <body>
    <?php require 'header.php'; ?>
    <main class="row">
      <h2>Iscriviti alla Biblioteca</h2>
      <div class="centered"><p>Questa è la pagina di iscrizione al nostro sito web. I requisiti dello <strong>username</strong> sono:
      <ul>
          <li>lo username può contenere solo caratteri alfabetici o numerici o '%';</li>
          <li>deve avere una lunghezza compresa tra 3 e 6 caratteri;</li>
          <li>deve contenere almeno un carattere alfabetico;</li>
          <li>deve contenere almeno un carattere numerico.</li>
      </ul>
      I requisiti della <strong>password</strong> invece sono:
      <ul>
        <li>deve contenere solo caratteri alfabetici;</li>
        <li>deve contenere almeno una lettera maiuscola</li>
        <li>deve essere compresa tra 4 e 8 caratteri.</li>

      </ul></p></div>
      <form method="post" onsubmit="return validaForm(username.value, password1.value, password2.value)" action="iscrizione.php">
          <p><label>Username* </label> <input type="text" name="username"></p>
          <p><label>Password* </label> <input type="password" name="password1" id="passw1"  oninput='validaFormLiveLength("passw1", "livel");' ></p>
          <p><output id="livel" ></p>
          <p><label>Ripeti la password* </label><input type="password" name="password2" id="passw2"  oninput='validaFormLive("passw1", "passw2", "livep");'></p>
          <p><output id="livep" ></p>
          <p><input type="submit"><input type="reset"></p>
      </form>
    </main>
    <?php require 'footer.php'; ?>
  </body>
</html>
