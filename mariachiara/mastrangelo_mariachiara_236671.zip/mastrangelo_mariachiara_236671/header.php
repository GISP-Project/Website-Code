<header class="row">
    <div class="col-12">
      <h1>Biblioteca prestiti online</h1>
    </div>
</header>
<nav class="row">
    <div class="col-2 menuitem"><a href="home.php" title='Home page'>Home</a></div>
    <div class="col-2 menuitem"><a title='Login' <?php
	 if (!isset($_SESSION['user']))
		 echo "href=login.php";
	 ?>>Login</a></div>
    <div class="col-2 menuitem"><a href="new.php" title="Registazione nuovo utente">New</a></div>
    <div class="col-2 menuitem"><a href="libri.php" title="Catalogo dei libri">Libri</a></div>
    <div class="col-2 menuitem"><a  title='Logout' <?php
	 if (isset($_SESSION['user']))
		 echo "href=logout.php";
	 ?>>Logout</a></div>
    <div class="col-2 menuitem">
      <?php
    if(!isset($_SESSION['user'])){
      echo "<a title='Non sei autenticato'>Anonimo, 0</a>";
    }
    else {
      echo "<a title='Sei autenticato'> ".$_SESSION['user'].", ".$_SESSION['nlibri']."</a>";
    }
    ?></div>
</nav>
