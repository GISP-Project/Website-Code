<?php
    $session = true;

if( session_status() === PHP_SESSION_DISABLED  )
    $session = false;
elseif( session_status() !== PHP_SESSION_ACTIVE )
{
	session_start();
}
?>
<!DOCTYPE html>
<html lang="it" >
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=yes">
    <meta name="author" content="Mariachiara Mastrangelo">
    <meta name="description" content="Servizio di biblioteca online per prendere in prestito e restituire i libri.">
    <meta name="keywords" content="bioblioteca, library, libro, book, prestito, online, restituzione">
    <link rel="icon" href="favicon.png" type="image/png" >
    <title>Home - Biblioteca online</title>
    <link rel="stylesheet" href="stile.css">
  </head>
  <body>
    <?php require 'header.php'; ?>
    <main class="row">
      <h2>BENVENUTO NELLA BIBLIOTECA PRESTITI ONLINE</h2>
        <img src="immagine_biblioteca.jpg" alt="Immagine della biblioteca" />
        <br />
        <div class="centrato">
        <h3>Il nostro sito...</h3>
        <p>Benvenuto nella nostra biblioteca online! Con il nostro innovativo servizio potrai usufruire di tutti i vantaggi
        di una biblioteca comodamente da casa tua. Basta semplicemente registrarsi dalla pagina new per avere un account
        ed accedere a tutto il nostro catalogo. Hai a disposizione centinaia di testi, che puoi liberamente prendere in prestito
        per quanti giorni desideri, l'unico limite è che puoi avere al massimo 3 prestiti in corso. </p>
        <br />

        <h3>...la nostra missione</h3>
        <p>Abbiamo a cuore la cultura e per questo abbiamo cercato di unire la nostra passione per i libri
        alla rivoluzione digitale e cosi è nata la nostra biblioteca online. La comodità di poter prendere in prestito i libri
        dal computer o addirittura dallo smartphone è un incredibile vantaggio ed uno stimolo alla lettura
        per tutti i nostri utenti. La nostra interfaccia è perfetta per ogni dispositivo ed è estremamente
        intuitiva, non avrete più scuse per non leggere! </p>
        <br />
        </div>
    </main>
    <?php require 'footer.php'; ?>
  </body>
</html>
