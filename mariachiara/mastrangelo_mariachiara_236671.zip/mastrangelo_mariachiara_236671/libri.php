<?php
    $session = true;

if( session_status() === PHP_SESSION_DISABLED  )
    $session = false;
elseif( session_status() !== PHP_SESSION_ACTIVE )
{
	session_start();
}
?>
<!DOCTYPE html>
<html lang="it" >
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=yes">
    <meta name="author" content="Mariachiara Mastrangelo">
    <meta name="description" content="Il nostro catalogo è pronto ad essere sfogliato da te.">
    <meta name="keywords" content="bioblioteca, library, libro, book, prestito, online, restituzione">
    <link rel="icon" href="favicon.png" type="image/png" >
    <title>Libri - Biblioteca online</title>
    <link rel="stylesheet" href="stile.css">

  </head>
  <body>
    <?php require 'header.php'; ?>
    <main class="row">

        <?php
        if (isset($_SESSION["user"])) {
            $con = mysqli_connect("localhost", "uReadOnly", "posso_solo_leggere", "biblioteca");
            if (mysqli_connect_errno())
                echo "<p class='error'>Siamo spiacenti ma c'è stato un errore connessione al database: ".mysqli_connect_error()."</p>\n";
            else{
              if ($_SESSION['nlibri']==0) {
                echo "<p class='error'>Non hai attualmente nessun libro in prestito, controlla la tabella qui sotto per scegliere
                un testo da prendere in prestito tra quelli disponibili</p>";
              }else {

                echo "<h2>I tuoi prestiti</h2>
                <p class='centrato'>In questa sezione puoi apprezzare tutti i libri che hai preso attualmente in prestito ed
                eventualmente restituirli tramite l'apposito bottone.</p>";
                $query = "SELECT id, titolo, autori, DATE(data) FROM books WHERE prestito='". $_SESSION['user'] ."'";
                $result = mysqli_query($con, $query);

                if (!$result) {
                  echo "<p class='error'>Errore query, fallita: ".mysqli_error($con)."</p>\n";
                } else {
                echo "<table class='row'>";
                echo "<thead class='hide'><th class='col-4'>Titolo</th><th class='col-4'>Autori</th><th class='col-4'>Resituisci</th></thead><tbody>";
                  while ($row = mysqli_fetch_assoc($result)) {
                    echo "<thead class='show'><th>Titolo</th></thead><tr><td class='col-4'>".$row['titolo']."</td><td class='col-4'>".$row['autori']."</td>
                    <td class='col-4'>
                    <form action='restituzione.php' method='POST'>
                    <input type='hidden' name='id' value='".$row['id']."'>
                    <input type='hidden' name='data' value='".$row['DATE(data)']."'>
                    <input type='submit' value='Restituisci'></form>
                    </td></tr>";
                  }
                echo "</tbody></table>";
                  mysqli_free_result($result);
                }
                }

                echo "<h2>Il nostro catalogo</h2>
                <p class='centrato'>In questa sezione puoi apprezzare il nostro intero catalogo. Scegliere un libro da prendere
                in prestito è molto semplice: basta cercare quelli con accanto il box per la selezione, cliccarci sopra e poi scegliere
                per quanti giorni vuoi avere il libro. Ricorda però che non puoi avere più di tre libri in prestito contemporaneamente.</p>";

                $query= "SELECT id, autori, titolo, DATE(data), giorni FROM books";
                $result= mysqli_query($con, $query);

                if (!$result) {
                  echo "<p class='error'>Errore, query fallita: ".mysqli_error($con)."</p>\n";
                } else {

                  echo "<table class='row'> <form action='prestito.php' method='POST'>";
                  echo "<thead class='hide'><th class='col-4'>Titolo</th><th class='col-4'>Autori</th><th class='col-4'>Prestito</th></thead><tbody>";
                  while ($row = mysqli_fetch_assoc($result)) {
                    $oggi = time();
                    $giorno = strtotime($row['DATE(data)']);
                    $durataprestito= $oggi - $giorno;
                    $durataprestito= round($durataprestito / (60 * 60 * 24));
                    if($row['DATE(data)']=="0000-00-00"){
                      //si può prendere in prestito
                      echo "<thead class='show'><th>Titolo</th></thead>
                      <tr><td class='col-4'>".$row['titolo']."</td><td class='col-4'>".$row['autori']."</td>
                      <td class='col-4'><input type='checkbox' name='id[]' value=".$row['id'].">
                      <input type='text' name='ngiorni[".$row['id']."]' value='' placeholder='Giorni' ></td></tr>";
                    }elseif ($durataprestito<$row['giorni']) {
                      //in prestito
                      echo "<thead class='show'><th>Titolo</th></thead>
                            <tr><td class='col-4'>".$row['titolo']."</td>
                            <td class='col-4'>".$row['autori']."</td>
                            <td class='col-4'>IN PRESTITO</td></tr>";
                    }else{
                      //prestito scaduto
                      echo "<thead class='show'><th>Titolo</th></thead>
                            <tr><td class='col-4'>".$row['titolo']."</td>
                            <td class='col-4'>".$row['autori']."</td>
                            <td class='col-4 error'>PRESTITO SCADUTO</td></tr>";
                    }
                  }
                  echo "<tr><td><input type='submit' value='Procedi con il prestito'></td></tr></tbody></form></table>";
                  mysqli_free_result($result);
                }


                mysqli_close($con);
                }

        } else {
          if (!$session) {
            echo "<p class='error'>Le sessioni sono disabilitae!</p>";
          }else{
            $con = mysqli_connect("localhost", "uReadWrite", "SuperPippo!!!", "biblioteca");
            if (mysqli_connect_errno()) {
                echo "<p class='error'>Siamo spiacenti ma c'è stato un errore connessione al database: ".mysqli_connect_error()."</p>\n";
              }else{
                //query riferita al numero totale di libri in biblioteca
                  $query = "SELECT COUNT(*) FROM books ";
                  $result = mysqli_query($con, $query);

                  if(!$result)
                        echo "<p class='error'>Errore query fallita: ".mysqli_error($con)."</p>\n";
                    else{
                      while ($row = mysqli_fetch_assoc($result)) {

                      echo "<p class='centrato'>Nella biblioteca ci sono: <strong> ".$row["COUNT(*)"]." libri </strong>.</p>";}
                    }
                    mysqli_free_result($result);
                //query per ottenere il numero di libri non in prestito
                    $query = "SELECT COUNT(*) FROM books WHERE prestito='' ";
                    $result = mysqli_query($con, $query);
                    if(!$result)
                          echo "<p class='error'>Errore, query fallita: ".mysqli_error($con)."</p>\n";
                      else{
                        while ($row = mysqli_fetch_assoc($result)) {
                        echo "<p class='centrato'>Nella biblioteca ci sono: <strong> ".$row["COUNT(*)"]." libri disponibili per il prestito. </strong></p>";}
                      }

                      mysqli_free_result($result);
              }
              mysqli_close($con);
          }

        }

         ?>
    </main>
    <?php require 'footer.php'; ?>
  </body>
</html>
